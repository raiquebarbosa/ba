import { Link } from "react-router-dom";
import { StyledFooter } from "./style";
import logo from "../../../assets/images/logo-grey.svg";

export const Footer = () => {
  return (
    <StyledFooter>
      <div className="container container__footer">
        <div className="footer__column1">
          <img src={logo} />
          <div className="container__infosDevs">
            <p>Desenvolvido por: Barra Delivery</p>
            </div>
          </div>
        </div>
        <div className="footer__column2">
          <p>Barra Delivery © Todos os direitos reservados.</p>
        </div>
      </div>
    </StyledFooter>
  );
};
